import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import copy as cp
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier as dtc
from sklearn.metrics import accuracy_score, confusion_matrix, precision_score, recall_score
from sklearn.ensemble import RandomForestClassifier as rfc
from sklearn import svm
from sklearn.model_selection import KFold
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D
import sys



#print(original_dataset.head())

#print(original_dataset.info())

def translate_to_origin(face_landmarks):
    
    face_landmarks = cp.deepcopy(face_landmarks)
    # Calculate average landmark coordinates
    avg_x = face_landmarks.iloc[:,:83].mean(axis=1)
    avg_y = face_landmarks.iloc[:,83:166].mean(axis=1)
    avg_z = face_landmarks.iloc[:,166:249].mean(axis=1)
    
    # print(avg_x, avg_y, avg_z)
    
    face_landmarks.iloc[:,:83] = face_landmarks.iloc[:,:83].sub(avg_x, axis=0)
    face_landmarks.iloc[:,84:166] = face_landmarks.iloc[:,84:166].sub(avg_y, axis=0)
    face_landmarks.iloc[:,166:249] = face_landmarks.iloc[:,166:249].sub(avg_z, axis=0)
    
    return face_landmarks
    


# print(translated_dataset.head())

def rotate_x(face_landmarks):
    face_landmarks = cp.deepcopy(face_landmarks)
    face_landmarks.iloc[:,84:166] = face_landmarks.iloc[:,84:166]*-1
    face_landmarks.iloc[:,166:249] = face_landmarks.iloc[:,166:249]*-1
    
    return face_landmarks

def rotate_y(face_landmarks):
    face_landmarks = cp.deepcopy(face_landmarks)
    face_landmarks.iloc[:,:83] = face_landmarks.iloc[:,:83]*-1
    face_landmarks.iloc[:,166:249] = face_landmarks.iloc[:,166:249]*-1
    
    return face_landmarks

def rotate_z(face_landmarks):
    face_landmarks = cp.deepcopy(face_landmarks)
    face_landmarks.iloc[:,:83] = face_landmarks.iloc[:,:83]*-1
    face_landmarks.iloc[:,84:166] = face_landmarks.iloc[:,84:166]*-1
    
    return face_landmarks

original_dataset=pd.read_csv('./facial_landmarks.csv')[:60000]
translated_dataset = translate_to_origin(original_dataset)

xrotated_dataset = rotate_x(original_dataset)
yrotated_dataset = rotate_y(original_dataset)
zrotated_dataset = rotate_z(original_dataset)

# data_set=[original_dataset, translated_dataset, xrotated_dataset, yrotated_dataset, zrotated_dataset]

data_set=[]
model=[]
user_ms = sys.argv[1]
if user_ms=="RF":
    model.append(rfc())
elif user_ms == "SVM":
    model.append(svm.SVC(kernel='linear'))
elif user_ms == "TREE":
    model.append(dtc())
    
user_data=sys.argv[2]
if user_data == "Original":
    data_set.append(original_dataset)
elif user_data == "Translated":
    data_set.append(translated_dataset)
elif user_data == "RotatedX":
    data_set.append(xrotated_dataset)
elif user_data == "RotatedY":
    data_set.append(yrotated_dataset)
elif user_data == "RotatedZ":
    data_set.append(zrotated_dataset)




# model=[rfc(), svm.SVC(kernel='linear'),dtc()]

for ds in data_set:
    df = ds[ds.columns]
    x = df.drop('expression', axis=1)
    y =df['expression']
    x_train, x_test, y_train, y_test, = train_test_split(x,y,test_size=0.3, random_state=40)

    

    
    kfold_val = KFold(n_splits=10)
    for ms in model:
        ms.fit(x_train, y_train)
        ms_predicted_labels = ms.predict(x_test)
        confusion_matrix_ms = confusion_matrix(y_test, ms_predicted_labels)
        accuracy_scores = []
        precision_scores = []
        recall_scores = []
        for i , j in kfold_val.split(x):
            x_train , x_test = x.iloc[i,:],x.iloc[j,:]
            y_train , y_test = y[i] , y[j]
            ms.fit(x_train,y_train)
            pred = ms.predict(x_test)
             
            accuracy = accuracy_score(pred , y_test)
            accuracy_scores.append(accuracy)
            precision=precision_score(pred, y_test, average='macro')
            precision_scores.append(precision)
            recall = recall_score(pred, y_test, average='macro')
            recall_scores.append(recall)
            
        print(sum(accuracy_scores)/10)
        print(sum(precision_scores)/10)
        print(sum(recall_scores)/10)
        print(confusion_matrix_ms)
    
# def draw_plot(face_landmarks):
#     fig = plt.figure(figsize=(10, 7))
#     axes = plt.axes(projection="3d")
#     x = face_landmarks.iloc[0:1,:83]
#     y = face_landmarks.iloc[0:1,83:166]
#     z = face_landmarks.iloc[0:1,166:249]
#     axes.scatter3D(x, y, z, color="green")
    
#     axes.set_xlabel('X')
#     axes.set_ylabel('Y')
#     axes.set_zlabel('Z')
#     plt.show()
    
# draw_plot(original_dataset)
# draw_plot(translated_dataset)
# draw_plot(xrotated_dataset)
# draw_plot(yrotated_dataset)
# draw_plot(zrotated_dataset)



# dt = dtc()
# dt.fit(x_train, y_train)
# dt_predicted_labels = dt.predict(x_test)
# dt_accuracy = accuracy_score(y_test, dt_predicted_labels)
# dt_precision = precision_score(y_test, dt_predicted_labels, average='macro')
# dt_recall = recall_score(y_test, dt_predicted_labels, average='macro')
# dt_confusion_matrix = confusion_matrix(y_test, dt_predicted_labels)
# print(dt_accuracy, dt_precision, dt_recall, dt_confusion_matrix)

# rf = rfc()
# rf.fit(x_train, y_train)
# rf_predicted_labels = rf.predict(x_test)
# rf_accuracy = accuracy_score(y_test, rf_predicted_labels)
# rf_precision = precision_score(y_test, rf_predicted_labels, average='macro')
# rf_recall = recall_score(y_test, rf_predicted_labels, average='macro')
# rf_confusion_matrix = confusion_matrix(y_test, rf_predicted_labels)
# print(rf_accuracy, rf_precision, rf_recall, rf_confusion_matrix)


# svm = svm.SVC(kernel='linear')
# svm.fit(x_train, y_train)
# svm_predicted_labels = svm.predict(x_test)
# svm_accuracy = accuracy_score(svm_predicted_labels, y_test)
# svm_precision = precision_score(y_test, svm_predicted_labels, average='macro')
# svm_recall = recall_score(y_test, svm_predicted_labels, average='macro')
# svm_confusion_matrix = confusion_matrix(y_test, svm_predicted_labels)
# print(svm_accuracy, svm_precision, svm_recall, svm_confusion_matrix)