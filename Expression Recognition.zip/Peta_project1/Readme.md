# Packages imported

- os
- csv
- pandas
- numpy
- matplotlib
- mpl_toolkits
- seaborn
- copy
- sklearn

## Instructions to run the code

- Make sure FacialLandmarks extracted folder is in the same folder where your python files are present
- Then run create_datasheet.py to generate csv datasheet from all given files.
- Then run project1.py
